package com.ggul.zip.tiper;

public class TiperVO {

	private int tiper_code;
	private String tiper_user_id;
	private String tiper_info;
	private String tiper_date;
	private String tiper_cate1;
	private String tiper_cate2;
	private String tiper_cate3;
	private String tiper_img;
	private String tiper_addr;
	private String tiper_cate1_stay;
	private String tiper_cate2_stay;
	private String tiper_cate3_stay;
	private int tiper_agree;

	public int getTiper_code() {
		return tiper_code;
	}

	public void setTiper_code(int tiper_code) {
		this.tiper_code = tiper_code;
	}

	public String getTiper_user_id() {
		return tiper_user_id;
	}

	public void setTiper_user_id(String tiper_user_id) {
		this.tiper_user_id = tiper_user_id;
	}

	public String getTiper_info() {
		return tiper_info;
	}

	public void setTiper_info(String tiper_info) {
		this.tiper_info = tiper_info;
	}

	public String getTiper_date() {
		return tiper_date;
	}

	public void setTiper_date(String tiper_date) {
		this.tiper_date = tiper_date;
	}

	public String getTiper_cate1() {
		return tiper_cate1;
	}

	public void setTiper_cate1(String tiper_cate1) {
		this.tiper_cate1 = tiper_cate1;
	}

	public String getTiper_cate2() {
		return tiper_cate2;
	}

	public void setTiper_cate2(String tiper_cate2) {
		this.tiper_cate2 = tiper_cate2;
	}

	public String getTiper_cate3() {
		return tiper_cate3;
	}

	public void setTiper_cate3(String tiper_cate3) {
		this.tiper_cate3 = tiper_cate3;
	}

	public String getTiper_img() {
		return tiper_img;
	}

	public void setTiper_img(String tiper_img) {
		this.tiper_img = tiper_img;
	}

	public String getTiper_addr() {
		return tiper_addr;
	}

	public void setTiper_addr(String tiper_addr) {
		this.tiper_addr = tiper_addr;
	}

	public String getTiper_cate1_stay() {
		return tiper_cate1_stay;
	}

	public void setTiper_cate1_stay(String tiper_cate1_stay) {
		this.tiper_cate1_stay = tiper_cate1_stay;
	}

	public String getTiper_cate2_stay() {
		return tiper_cate2_stay;
	}

	public void setTiper_cate2_stay(String tiper_cate2_stay) {
		this.tiper_cate2_stay = tiper_cate2_stay;
	}

	public String getTiper_cate3_stay() {
		return tiper_cate3_stay;
	}

	public void setTiper_cate3_stay(String tiper_cate3_stay) {
		this.tiper_cate3_stay = tiper_cate3_stay;
	}

	public int getTiper_agree() {
		return tiper_agree;
	}

	public void setTiper_agree(int tiper_agree) {
		this.tiper_agree = tiper_agree;
	}

}
